import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# إعداد المجلد لحفظ الصور
os.makedirs("figures", exist_ok=True)

# تحميل البيانات
data = pd.read_csv("netflix_titles.csv")

# ==================== Data Cleaning ====================
data["cast"].fillna("unknown", inplace=True)
data["country"].fillna("unknown", inplace=True)
data["director"].fillna("unknown", inplace=True)
data["date_added"].fillna("unknown", inplace=True)

data = data[data['rating'].str.lower() != 'unknown']
data.dropna(subset=['rating'], inplace=True)
data = data[data['duration'] != 'unknown']
data.dropna(subset=['duration'], inplace=True)

# ==================== Helper Functions ====================
def save_pie_chart(values, labels, title, filename):
    plt.figure(figsize=(7, 7))
    plt.pie(values, labels=labels, autopct='%1.1f%%', startangle=90)
    plt.title(title, fontsize=13, fontweight='bold')
    plt.axis('equal')
    plt.tight_layout()
    plt.savefig(f"figures/{filename}_pie.png", bbox_inches="tight", dpi=300)
    plt.close()

def save_bar_chart(values, labels, title, xlabel, ylabel, filename, color="skyblue"):
    plt.figure(figsize=(10, 6))
    bars = plt.bar(labels, values, color=color, edgecolor='black')
    plt.xticks(rotation=45, ha='right')
    plt.title(title, fontsize=13, fontweight='bold')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, yval + 0.2, f"{yval:.1f}%", ha='center', fontsize=9)
    plt.savefig(f"figures/{filename}_bar.png", bbox_inches="tight", dpi=300)
    plt.close()

# ==================== Global Analysis ====================
print("\n=== CONTENT TYPE ANALYSIS ===")
type_presentation = data["type"].value_counts(normalize=True) * 100
save_pie_chart(type_presentation, type_presentation.index, "Types of content on Netflix", "type_overview")
save_bar_chart(type_presentation.values, type_presentation.index, "Types of content on Netflix", "Type", "Percentage", "type_overview")

print("\n=== CATEGORY ANALYSIS ===")
listed_presentation = data["listed_in"].value_counts(normalize=True) * 100
top10 = listed_presentation.head(10)
save_pie_chart(top10, top10.index, "Top 10 Categories on Netflix", "categories_top10")
save_bar_chart(top10.values, top10.index, "Top 10 Categories on Netflix", "Category", "Percentage", "categories_top10")

print("\n=== COUNTRY ANALYSIS ===")
country_presentation = data["country"].value_counts(normalize=True) * 100
top10 = country_presentation.head(10)
save_pie_chart(top10, top10.index, "Top 10 Content-Producing Countries", "countries_top10")
save_bar_chart(top10.values, top10.index, "Top 10 Content-Producing Countries", "Country", "Percentage", "countries_top10")

# ==================== Country-specific ====================
def analyze_country(data, country_name):
    country_data = data[data['country'].str.contains(country_name, na=False)]
    if len(country_data) == 0:
        print(f"No data found for {country_name}.")
        return

    print(f"\n=== {country_name.upper()} TYPE ANALYSIS ===")
    type_counts = country_data['type'].value_counts(normalize=True) * 100
    save_pie_chart(type_counts, type_counts.index, f"Content Type in {country_name}", f"{country_name}_type")
    save_bar_chart(type_counts.values, type_counts.index, f"Content Type in {country_name}", "Type", "Percentage", f"{country_name}_type")

    print(f"\n=== {country_name.upper()} CATEGORY ANALYSIS ===")
    category_counts = country_data['listed_in'].value_counts(normalize=True) * 100
    top10 = category_counts.head(10)
    save_pie_chart(top10, top10.index, f"Top 10 Categories in {country_name}", f"{country_name}_categories")
    save_bar_chart(top10.values, top10.index, f"Top 10 Categories in {country_name}", "Category", "Percentage", f"{country_name}_categories")

analyze_country(data, "United States")
analyze_country(data, "India")

# ==================== Rating Analysis ====================
def analyze_rating(data, type_name):
    type_data = data[data['type'] == type_name]
    rating_presentation = type_data['rating'].value_counts(normalize=True) * 100
    top6 = rating_presentation.head(6)
    print(f"\n=== {type_name.upper()} RATING ANALYSIS ===")
    print(top6)
    save_pie_chart(top6, top6.index, f"Ratings of {type_name}s", f"{type_name}_ratings")
    save_bar_chart(top6.values, top6.index, f"Ratings of {type_name}s", "Rating", "Percentage", f"{type_name}_ratings")

analyze_rating(data, "Movie")
analyze_rating(data, "TV Show")

print("\n✅ All charts (Pie + Bar) have been saved in the 'figures' folder successfully!")
